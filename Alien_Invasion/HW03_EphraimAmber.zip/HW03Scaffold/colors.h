/* Custom Colors */

// from HW1
#define PINK 0x59FF
#define CROWN_YELLOW 0x1EFE
#define GLOW_PINK 0x7A5F
#define GLOW_PURPLE 0x4892
#define C_GRAY 0x318C

// from HW2
#define FROG_GREEN 0x15A2
#define LOG_BROWN 0x1530
#define WATER_BLUE 0x72C4
#define GRASS_GREEN 0x2B44

// from HW3
#define GLASS 0x7FFC
#define DARK_BLUE 0x5021
#define TEAL 0x5F67
#define HOT_PINK 0x409D
#define LIGHT_PURPLE 0x7DD4
#define NEON_GREEN 0x33F5
#define ORANGE 0x1DBE
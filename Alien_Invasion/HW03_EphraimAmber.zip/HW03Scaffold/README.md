
**ALIEN INVASION**

# Button Controls:

GBA Buttons -> Keyboard Equivalent
START -> Spacebar
A -> X
UP -> Up arrow Key
DOWN -> Down arrow Key
LEFT -> Left arrow key
RIGHT -> Right arrow Key
*The controls support multiple key presses at once (that are not in opposite deirections) EX: UP, Right, and X*

# Navigate State Machine:

On the START screen, press the spacebar to start the game
During the game, press the spacebar to pause and unpause the game
At the losing screen, press the spacebar to return to the START screen

# How To Play:

This is a survival game. The objective is to take out as many invading aliens as you can. Use the 'X' button
to shoot a laser in the same direction you're traveling. If you run into an enemey, accidently shoot your planet,
crash into the planet, or let an invader past your defenses, you will lose a life. During the game, powerups will appear on the screen.
Golden stars give the player a speed boost. Purple stars give the player an extra life. Survive for as long as possible.
// shoot sound made by wav2c

extern const unsigned int shoot_sampleRate;
extern const unsigned int shoot_length;
extern const signed char shoot_data[];

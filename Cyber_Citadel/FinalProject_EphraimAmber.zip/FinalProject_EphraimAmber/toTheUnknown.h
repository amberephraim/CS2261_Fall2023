// toTheUnknown sound made by wav2c

extern const unsigned int toTheUnknown_sampleRate;
extern const unsigned int toTheUnknown_length;
extern const signed char toTheUnknown_data[];

// theHiddenOne sound made by wav2c

extern const unsigned int theHiddenOne_sampleRate;
extern const unsigned int theHiddenOne_length;
extern const signed char theHiddenOne_data[];

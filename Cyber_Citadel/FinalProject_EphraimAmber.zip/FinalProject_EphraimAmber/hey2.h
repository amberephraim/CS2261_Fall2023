// hey2 sound made by wav2c

extern const unsigned int hey2_sampleRate;
extern const unsigned int hey2_length;
extern const signed char hey2_data[];

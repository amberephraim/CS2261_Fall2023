// hi2 sound made by wav2c

extern const unsigned int hi2_sampleRate;
extern const unsigned int hi2_length;
extern const signed char hi2_data[];

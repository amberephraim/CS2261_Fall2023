
// Hello for NPC 1
extern const unsigned int hello1_sampleRate;
extern const unsigned int hello1_length;
extern const signed char hello1_data[];

// Lightyear_City sound made by wav2c
extern const unsigned int Lightyear_City_sampleRate;
extern const unsigned int Lightyear_City_length;
extern const signed char Lightyear_City_data[];


// move sound made by wav2c

extern const unsigned int move_sampleRate;
extern const unsigned int move_length;
extern const signed char move_data[];

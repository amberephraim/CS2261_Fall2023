// valleyofSpirits sound made by wav2c

extern const unsigned int valleyofSpirits_sampleRate;
extern const unsigned int valleyofSpirits_length;
extern const signed char valleyofSpirits_data[];

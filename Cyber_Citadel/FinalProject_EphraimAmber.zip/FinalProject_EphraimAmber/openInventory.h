// openInventory sound made by wav2c

extern const unsigned int openInventory_sampleRate;
extern const unsigned int openInventory_length;
extern const signed char openInventory_data[];

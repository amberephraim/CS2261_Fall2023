// INTERFACES - START, PAUSE, INVENTORY, INSTRUCTIONS
#define interfaceSSTilesLen 32768
extern const unsigned short interfaceSSTiles[16384];

#define interfaceSSPalLen 512
extern const unsigned short interfaceSSPal[256];

// MAINSTREET
#define mainSSTilesLen 32768
extern const unsigned short mainSSTiles[16384];

#define mainSSPalLen 512
extern const unsigned short mainSSPal[256];

// AREA 1
#define area1SSTilesLen 32768
extern const unsigned short area1SSTiles[16384];

#define area1SSPalLen 512
extern const unsigned short area1SSPal[256];


// AREA 2
#define area2SSTilesLen 32768
extern const unsigned short area2SSTiles[16384];

#define area2SSPalLen 512
extern const unsigned short area2SSPal[256];

// FINAL
#define finalSSTilesLen 32768
extern const unsigned short finalSSTiles[16384];

#define finalSSPalLen 512
extern const unsigned short finalSSPal[256];

// TEXT
#define textSSTilesLen 32768
extern const unsigned short textSSTiles[16384];

#define textSSPalLen 512
extern const unsigned short textSSPal[256];
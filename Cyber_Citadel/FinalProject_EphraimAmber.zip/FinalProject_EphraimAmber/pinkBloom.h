// pinkBloom sound made by wav2c

extern const unsigned int pinkBloom_sampleRate;
extern const unsigned int pinkBloom_length;
extern const signed char pinkBloom_data[];

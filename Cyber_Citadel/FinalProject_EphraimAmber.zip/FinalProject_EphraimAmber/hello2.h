// hello2 sound made by wav2c

extern const unsigned int hello2_sampleRate;
extern const unsigned int hello2_length;
extern const signed char hello2_data[];

#ifndef PAUSE_H
#define PAUSE_H

#define PAUSE_WIDTH  (32)
#define PAUSE_HEIGHT (32)
#define pauseMapLen (2048)

extern const unsigned short pauseMap[1024];

#endif

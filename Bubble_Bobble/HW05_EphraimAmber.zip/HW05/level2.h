#ifndef LEVEL2_H
#define LEVEL2_H

#define LEVEL2_WIDTH  (32)
#define LEVEL2_HEIGHT (32)
#define level2MapLen (2048)

extern const unsigned short level2Map[1024];

#endif


//{{BLOCK(level2collisionmap)

//======================================================================
//
//	level2collisionmap, 240x160@8, 
//	+ bitmap not compressed
//	Total size: 38400 = 38400
//
//	Time-stamp: 2023-10-28, 16:40:40
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL2COLLISIONMAP_H
#define GRIT_LEVEL2COLLISIONMAP_H

#define level2collisionmapBitmapLen 38400
extern const unsigned char level2collisionmapBitmap[38400];

#endif // GRIT_LEVEL2COLLISIONMAP_H

//}}BLOCK(level2collisionmap)

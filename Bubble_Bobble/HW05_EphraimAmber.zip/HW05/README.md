**Bubble Bobble**

# Controls
Left Button - move left
Right Button - move right
Up Button - jump
A - blow bubble

# How to play
Use the left, right, and up buttons to make the player move. Press A to blow a bubble and trap the enemies. When the enemies are
trapped in the bubble hit them to kill them. Once the enemies are killed, they turn into food that can be collected for points.
Be quick, the bubbles and food disappear if you take too long. Complete both levels to win.

# Implementation
Enemy types
Type 1: toy robot
Type 3: skeleton ghost
Type 4: wizard

Food animation: 
green 50 animation where the food was
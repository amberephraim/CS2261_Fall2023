
//{{BLOCK(level1collisionmap)

//======================================================================
//
//	level1collisionmap, 240x160@8, 
//	+ bitmap not compressed
//	Total size: 38400 = 38400
//
//	Time-stamp: 2023-10-28, 16:41:33
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL1COLLISIONMAP_H
#define GRIT_LEVEL1COLLISIONMAP_H

#define level1collisionmapBitmapLen 38400
extern const unsigned char level1collisionmapBitmap[38400];

#endif // GRIT_LEVEL1COLLISIONMAP_H

//}}BLOCK(level1collisionmap)

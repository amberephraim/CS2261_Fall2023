How to Play?

Use the arrow keys to move the frog to the grass at the top of the screen.
Be careful, if the frog gets hit by a car it will lose a life and have to start over. 
When crossing the river land on the logs and the lilypad, if the frog falls in the river or goes off screen, it will also lose a life.

You start the game with 3 lives, displayed in the top left corner. Once you run out of lives, the game is over and you have lost.

Once you reach the grass at the top, you will win the game.
/* Custom Colors */

// from HW1
#define PINK 0x59FF
#define CROWN_YELLOW 0x1EFE
#define GLOW_PINK 0x7A5F
#define GLOW_PURPLE 0x4892
#define C_GRAY 0x318C

// from HW2
#define FROG_GREEN 0x15A2
#define LOG_BROWN 0x1530
#define WATER_BLUE 0x72C4
#define GRASS_GREEN 0x2B44
